Virtual Reality, Visual Cliffs and Movement Disorders Fall 2017 Research

The OpenVibe design and related files and scripting needed to run the project

Authors: FA2017 VCVR IGL team